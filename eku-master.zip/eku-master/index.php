<?php
define('APP','app/');
require(APP.'b2core.php');

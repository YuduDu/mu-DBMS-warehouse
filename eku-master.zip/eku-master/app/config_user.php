<?php
define('BASE','?/');
define('SEED','oivzzl17');
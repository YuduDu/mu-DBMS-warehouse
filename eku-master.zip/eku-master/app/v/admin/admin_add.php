<form class="form-inline" method="post" action="">
  <div class="form-group">
    <label>用户名</label>
    <input type="text" name="Username" class="form-control">
  </div>
  <div class="form-group">
    <label>密码</label>
    <input type="text" name="Password" class="form-control">
  </div>
  <div class="form-group">
    <label>员工编号</label>
    <input type="text" name="Staffs_Sid" class="form-control">
  </div>
  
  <br><div class="form-group">
    <button type="submit" name="admin_add" class="btn btn-default">添加</button>
  </div>
</form>
<form class="form-inline" method="post" action="">
  <div class="form-group">
    <label>客户公司名称</label>
    <input type="text" name="Cname" class="form-control">
  </div>
  <div class="form-group">
    <label>客户联系人姓名</label>
    <input type="text" name="Ccontact" class="form-control">
  </div>
  <div class="form-group">
    <label>客户地址</label>
    <input type="text" name="Caddress" class="form-control">
  </div>
  <div class="form-group">
    <label>客户邮编</label>
    <input type="text" name="Cpostcode" class="form-control">
  </div>
  <div class="form-group">
    <label>客户电话</label>
    <input type="text" name="Cphone" class="form-control">
  </div>
  <div class="form-group">
    <label>客户银行</label>
    <input type="text" name="Cbank" class="form-control">
  </div>
  <div class="form-group">
    <label>客户银行账号</label>
    <input type="text" name="Caccount" class="form-control">
  </div>
  
  <br><div class="form-group">
    <button type="submit" name="customer_add" class="btn btn-default">添加</button>
  </div>
</form>
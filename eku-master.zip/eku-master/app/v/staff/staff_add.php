<form class="form-inline" method="post" action="">
  <div class="form-group">
    <label>名字</label>
    <input type="text" name="Sname" class="form-control">
  </div>
  <div class="form-group">
    <label>员工类型的编号</label>
    <input type="text" name="SCid" class="form-control">
  </div>
  <div class="form-group">
    <label>电话</label>
    <input type="text" name="Sphone" class="form-control">
  </div>
  
  <br><div class="form-group">
    <button type="submit" name="staff_add" class="btn btn-default">添加</button>
  </div>
</form>
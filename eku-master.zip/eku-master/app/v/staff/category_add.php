<form class="form-inline" method="post" action="">
  <div class="form-group">
    <label>员工类型ID</label>
    <input type="text" name="SCid" class="form-control">
  </div>
  <div class="form-group">
    <label>员工类型描述</label>
    <input type="text" name="SType" class="form-control">
  </div>
  
  <br><div class="form-group">
    <button type="submit" name="category_add" class="btn btn-default">添加</button>
  </div>
</form>
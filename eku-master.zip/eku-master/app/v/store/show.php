
<table class="table-view  table" cellspacing=0 >
  <tr>
    <th>ekuid</th>
    <td><?=$r[eku_id] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[pid] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[pname] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[unit] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[num] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[action] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[action_label] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[alert_level] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[kuwei] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[datetime] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[doer] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[remark] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[category] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[balance] ?></td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td><?=$r[cur_balance] ?></td>
  </tr>
</table>

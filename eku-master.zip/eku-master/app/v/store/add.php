
<form method="POST" ><table class="table-add table" cellspacing=0 >
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="eku_id" value="<?=isset($val['eku_id'])?$val['eku_id']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['eku_id'])?$err['eku_id']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="pid" value="<?=isset($val['pid'])?$val['pid']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['pid'])?$err['pid']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="pname" value="<?=isset($val['pname'])?$val['pname']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['pname'])?$err['pname']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="unit" value="<?=isset($val['unit'])?$val['unit']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['unit'])?$err['unit']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="num" value="<?=isset($val['num'])?$val['num']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['num'])?$err['num']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="action" value="<?=isset($val['action'])?$val['action']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['action'])?$err['action']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="action_label" value="<?=isset($val['action_label'])?$val['action_label']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['action_label'])?$err['action_label']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="alert_level" value="<?=isset($val['alert_level'])?$val['alert_level']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['alert_level'])?$err['alert_level']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="kuwei" value="<?=isset($val['kuwei'])?$val['kuwei']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['kuwei'])?$err['kuwei']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="datetime" value="<?=isset($val['datetime'])?$val['datetime']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['datetime'])?$err['datetime']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="doer" value="<?=isset($val['doer'])?$val['doer']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['doer'])?$err['doer']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="remark" value="<?=isset($val['remark'])?$val['remark']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['remark'])?$err['remark']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="category" value="<?=isset($val['category'])?$val['category']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['category'])?$err['category']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="balance" value="<?=isset($val['balance'])?$val['balance']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['balance'])?$err['balance']:''?></span>
    </td>
  </tr>
  <tr>
    <th>ekuid</th>
    <td>
      <input class="text" name="cur_balance" value="<?=isset($val['cur_balance'])?$val['cur_balance']:''?>" >
    </td>
    <td>
      <span class="error" ><?=isset($err['cur_balance'])?$err['cur_balance']:''?></span>
    </td>
  </tr>
  <tr>
    <th></th><td><input type="submit" class="submit-button" value="确认提交" ></td>
  </tr>
</table></form>
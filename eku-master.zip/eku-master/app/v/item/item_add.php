<form class="form-inline" method="post" action="">
  <div class="form-group">
    <label>物品的名称</label>
    <input type="text" name="Iname" class="form-control">
  </div>
  <div class="form-group">
    <label>物品的大类</label>
    <input type="text" name="ICname" class="form-control">
  </div>
  <div class="form-group">
    <label>物品的计量单位</label>
    <input type="text" name="Unit" class="form-control">
  </div>
  
  <br><div class="form-group">
    <button type="submit" name="item_add" class="btn btn-default">添加</button>
  </div>
</form>
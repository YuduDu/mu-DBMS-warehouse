<form class="form-inline" method="post" action="">
  <div class="form-group">
    <label>物品的大类</label>
    <input type="text" name="ICname" class="form-control">
  </div>
  <div class="form-group">
    <label>物品的大类</label>
  <select class="form-control" name="Spec">
    <option value="原材料">原材料</option>
    <option value="半成品">半成品</option>
    <option value="成品">成品</option>
  </select>
  </div>
  
  <br><div class="form-group">  
    <button type="submit" name="item_add" class="btn btn-default">添加</button>
  </div>
</form>
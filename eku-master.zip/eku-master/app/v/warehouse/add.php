<form class="form-inline" method="post" action="">
  <div class="form-group">
    <label>仓库负责员工的编号</label>
    <input type="text" name="Admin_id" class="form-control">
  </div>
  
  <br><div class="form-group">
    <button type="submit" name="warehouses_add" class="btn btn-default">添加</button>
  </div>
</form>
<!DOCTYPE html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>900APP | 企业管理软件</title>
<meta name="keywords" content="免费,在线,仓库管理,软件,云计算"/>
<meta name="description" content="免费在线仓库管理软件"/>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="black" name="apple-mobile-web-app-status-bar-style" />
<link href="<?=BASE?>static/default.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
  <div class="win" style="margin: 120px auto;padding: 20px;border: solid 5px #eee;color: #666;background:#fff url(http://900app.sinaapp.com/static/chrome.png) right bottom no-repeat;"  >
  <h1>Chrome Only</h1>
  
  抱歉，您使用的是非 Chrome 浏览器<br />
  目前系统仅支持 <a href="http://www.google.cn/intl/zh-CN/chrome/browser/" target="blank"  >Chrome</a> 浏览器访问<br />
   <a href="http://www.google.cn/intl/zh-CN/chrome/browser/" target="blank"  >下载最新版 Google Chrome</a>
 </div>
 </div>
</body>
</html>


<table class="table-view  table" cellspacing=0 >
  <tr>
    <th>email</th>
    <td><?=$r[email] ?></td>
  </tr>
  <tr>
    <th>用户名</th>
    <td><?=$r[username] ?></td>
  </tr>
  <tr>
    <th>密码</th>
    <td><?=$r[password] ?></td>
  </tr>
  <tr>
    <th>发布时间</th>
    <td><?=$r[post_time] ?></td>
  </tr>
  <tr>
    <th>更新时间</th>
    <td><?=$r[update_time] ?></td>
  </tr>
  <tr>
    <th>级别</th>
    <td><?=$r[level] ?></td>
  </tr>
  <tr>
    <th>信息</th>
    <td><?=$r[info] ?></td>
  </tr>
</table>
